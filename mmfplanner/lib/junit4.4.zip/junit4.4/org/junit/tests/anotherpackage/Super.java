package org.junit.tests.anotherpackage;

import org.junit.Test;

class Super {
	@Test public void a() {}
}
